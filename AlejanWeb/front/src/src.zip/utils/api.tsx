import axios from 'axios';

const api = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_URI || 'http://localhost:4011/',
    headers: { 'X-Custom-Header': 'foobar' }
});

export default api;

