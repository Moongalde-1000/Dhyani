'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import {
  Box,
  Button,
  Paper,
  Stack,
  Typography,
  CircularProgress,
  Grid,
  Divider,
  BoxProps
} from '@mui/material'
import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'

interface DetailItemProps extends BoxProps {
  label: string
  value?: React.ReactNode
  xs?: number
  md?: number
}

const DetailItem = ({ label, value, xs = 12, md = 6, ...props }: DetailItemProps) => (
  <Grid item xs={xs} md={md} {...props}>
    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
      {label}
    </Typography>
    <Typography variant="body1" sx={{ wordBreak: 'break-word' }}>
      {value || '-'}
    </Typography>
  </Grid>
)

interface User {
  id: string
  _id: string
  fullName: string
  displayName: string
  email: string
  phone?: string
  gender?: string
  dateOfBirth?: string
  location?: string
  profileImage?: string
  qrCodeUrl?: string
  publicProfileUrl?: string
  height?: string
  bodyType?: string
  ethnicity?: string
  religion?: string
  zodiac?: string
  language?: string[]
  relationShip?: string
  kids?: string
  pets?: string
  jobTitle?: string
  company?: string
  isSmoking?: string
  isDrinking?: string
  bio?: string
  role: string
  is_suspended: boolean
  lastLoginAt?: string
  createdAt: string
  updatedAt: string
}

const UserViewPage = () => {
  const [user, setUser] = useState<User | null>(null)
  const [friends, setFriends] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingFriends, setLoadingFriends] = useState(false)
  const [isOpenNotification, setIsOpenNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')

  const router = useRouter()
  const params = useParams()
  const userId = params?.id as string

  const getUserDetails = async () => {
    try {
      setLoading(true)
      const api = await useAPI()
      const response = await api.userManagement.getById(userId)

      if (response.data?.data) {
        setUser(response.data.data)
      }
    } catch (error: any) {
      console.error('Error fetching user details:', error)
      setNotificationMessage(error.response?.data?.message || 'Error fetching user details')
      setIsOpenNotification(true)
    } finally {
      setLoading(false)
    }
  }

  const getFriends = async () => {
    try {
      setLoadingFriends(true)
      const api = await useAPI()
      const response = await api.friend.get({ userId })

      if (response.data?.success && response.data?.data) {
        setFriends(response.data.data)
      }
    } catch (error: any) {
      console.error('Error fetching friends:', error)
    } finally {
      setLoadingFriends(false)
    }
  }

  useEffect(() => {
    if (userId) {
      getUserDetails()
      getFriends()
    }
  }, [userId])

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress />
      </Box>
    )
  }

  if (!user) {
    return (
      <Box p={4}>
        <Typography variant="h5">User not found</Typography>
        <Button variant="contained" onClick={() => router.push('/admin/user')} sx={{ mt: 2 }}>
          Back to Users
        </Button>
      </Box>
    )
  }

  return (
    <Box p={4}>
      <Paper sx={{ p: 4 }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h4">User Details</Typography>
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" onClick={() => router.push('/admin/user')}>
              Back to Users
            </Button>
          </Stack>
        </Stack>

        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>Basic Information</Typography>
            <Grid container spacing={2}>
              <DetailItem label="Full Name" value={user.fullName} />
              <DetailItem label="Display Name" value={user.displayName} />
              <DetailItem label="Email" value={user.email} />
              <DetailItem label="Phone" value={user.phone} />
              <DetailItem label="Gender" value={user.gender} />
              <DetailItem label="Date of Birth" value={user.dateOfBirth ? new Date(user.dateOfBirth).toLocaleDateString() : ''} />
              <DetailItem label="Location" value={user.location} />
              <DetailItem label="Role" value={user.role} />
              <DetailItem label="Status" value={user.is_suspended ? 'Suspended' : 'Active'} />
            </Grid>
          </Grid>

          <Grid item xs={12} md={6}>
            <Typography variant="h6" gutterBottom>Profile Information</Typography>
            <Grid container spacing={2}>
              <DetailItem label="Height" value={user.height} />
              <DetailItem label="Body Type" value={user.bodyType} />
              <DetailItem label="Ethnicity" value={user.ethnicity} />
              <DetailItem label="Religion" value={user.religion} />
              <DetailItem label="Zodiac" value={user.zodiac} />
              <DetailItem label="Languages" value={user.language?.join(', ')} />
              <DetailItem label="Relationship Status" value={user.relationShip} />
              <DetailItem label="Kids" value={user.kids} />
              <DetailItem label="Pets" value={user.pets} />
            </Grid>
          </Grid>

          <Grid item xs={12}>
            <Divider sx={{ my: 3 }} />
            <Typography variant="h6" gutterBottom>Professional Information</Typography>
            <Grid container spacing={2}>
              <DetailItem label="Job Title" value={user.jobTitle} xs={12} md={6} />
              <DetailItem label="Company" value={user.company} xs={12} md={6} />
              <DetailItem label="Smoking" value={user.isSmoking === '1' ? 'Yes' : 'No'} xs={6} md={3} />
              <DetailItem label="Drinking" value={user.isDrinking === '1' ? 'Yes' : 'No'} xs={6} md={3} />
            </Grid>
          </Grid>

          {user.bio && (
            <Grid item xs={12}>
              <Divider sx={{ my: 3 }} />
              <Typography variant="h6" gutterBottom>Bio</Typography>
              <Paper variant="outlined" sx={{ p: 2, bgcolor: 'background.paper' }}>
                <Typography>{user.bio}</Typography>
              </Paper>
            </Grid>
          )}

          <Grid item xs={12}>
            <Divider sx={{ my: 3 }} />
            <Typography variant="h6" gutterBottom>System Information</Typography>
            <Grid container spacing={2}>
              <DetailItem label="User ID" value={user.id} xs={12} md={6} />
              <DetailItem label="Created At" value={new Date(user.createdAt).toLocaleString()} xs={12} md={6} />
              <DetailItem label="Last Updated" value={new Date(user.updatedAt).toLocaleString()} xs={12} md={6} />
              <DetailItem label="Last Login" value={user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString() : 'Never'} xs={12} md={6} />
            </Grid>
          </Grid>

          {(user.profileImage || user.qrCodeUrl) && (
            <Grid item xs={12}>
              <Divider sx={{ my: 3 }} />
              <Typography variant="h6" gutterBottom>Media</Typography>
              <Grid container spacing={2}>
                {user.profileImage && (
                  <Grid item xs={12} md={6}>
                    <Typography variant="subtitle2" gutterBottom>Profile Image</Typography>
                    <Box
                      component="img"
                      src={user.profileImage}
                      alt="Profile"
                      sx={{
                        maxWidth: '100%',
                        maxHeight: 300,
                        borderRadius: 1,
                        border: '1px solid',
                        borderColor: 'divider'
                      }}
                    />
                  </Grid>
                )}
                {user.qrCodeUrl && (
                  <Grid item xs={12} md={6}>
                    <Typography variant="subtitle2" gutterBottom>QR Code</Typography>
                    <Box
                      component="img"
                      src={user.qrCodeUrl}
                      alt="QR Code"
                      sx={{
                        maxWidth: '100%',
                        maxHeight: 300,
                        border: '1px solid',
                        borderColor: 'divider',
                        p: 1,
                        bgcolor: 'white'
                      }}
                    />
                  </Grid>
                )}
              </Grid>
            </Grid>
          )}

          <Grid item xs={12}>
            <Divider sx={{ my: 3 }} />
            <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">Friends List ({friends.length})</Typography>
              {loadingFriends && <CircularProgress size={20} />}
            </Stack>
            {friends.length > 0 ? (
              <Grid container spacing={2}>
                {friends.map((friend) => (
                  <Grid item xs={12} sm={6} md={4} key={friend.id}>
                    <Paper
                      variant="outlined"
                      sx={{
                        p: 2,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 2,
                        cursor: 'pointer',
                        '&:hover': { bgcolor: 'action.hover' }
                      }}
                      onClick={() => router.push(`/admin/user/${friend.id}`)}
                    >
                      <Box
                        component="img"
                        src={friend.profileImage || '/images/avatars/1.png'}
                        alt={friend.fullName}
                        sx={{
                          width: 50,
                          height: 50,
                          borderRadius: '50%',
                          objectFit: 'cover',
                          border: '1px solid',
                          borderColor: 'divider'
                        }}
                      />
                      <Box sx={{ minWidth: 0 }}>
                        <Typography variant="subtitle2" noWrap>
                          {friend.fullName || friend.displayName}
                        </Typography>
                        <Typography variant="caption" color="text.secondary" noWrap display="block">
                          {friend.email}
                        </Typography>
                        {friend.isBlocked === 1 && (
                          <Typography variant="caption" color="error" sx={{ fontWeight: 'bold' }}>
                            Blocked
                          </Typography>
                        )}
                      </Box>
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Typography variant="body2" color="text.secondary">
                {loadingFriends ? 'Loading friends...' : 'No friends found'}
              </Typography>
            )}
          </Grid>
        </Grid>

        <Divider sx={{ mb: 3 }} />

      </Paper>

      <Notification
        open={isOpenNotification}
        onClose={() => setIsOpenNotification(false)}
        message={notificationMessage}
      />
    </Box>
  )
}

export default UserViewPage
