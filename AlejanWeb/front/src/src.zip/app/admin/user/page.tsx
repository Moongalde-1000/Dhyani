'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

import {
  Box,
  Button,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TableSortLabel,
  MenuItem
} from '@mui/material'

import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'

interface GoalData {
  goalId: string
  goalTitle: string
  completedSessions: number
}

interface User {
  _id: string
  id: string
  fullName: string
  email: string
  phone: string
  createdAt: string
  location?: string
  country?: string
  is_suspended: boolean
  role?: string
}

// Define the sortable columns keys
type SortKey = 'fullName' | 'email' | 'phone' | 'createdAt'

const UserPage = () => {
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [users, setUsers] = useState<User[]>([])
  const [defaultUsers, setDefaultUsers] = useState<User[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [deleteUserId, setDeleteUserId] = useState('')
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [isOpenNotification, setIsOpenNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' } | null>(null)
  const [suspendingId, setSuspendingId] = useState<string>('')
  const [countryFilter, setCountryFilter] = useState<string>('')
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'SUSPENDED'>('ALL')

  const router = useRouter()
  const api = useAPI()

  const getUsers = async () => {
    try {
      setLoading(true)
      const response = await (await api).userManagement.get()
      if (response.data?.data) {
        setUsers(response.data.data)
        setDefaultUsers(response.data.data)
      }
    } catch (error: any) {
      console.error('Error fetching users:', error)
      setNotificationMessage(error.response?.data?.message || 'Error fetching users')
      setIsOpenNotification(true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    getUsers()
  }, [])

  // Sorting function
  const handleSort = (key: SortKey) => {
    let direction: 'asc' | 'desc' = 'asc'
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc'
    }
    setSortConfig({ key, direction })
  }

  // Apply sorting and searching
  const getFilteredSortedUsers = () => {
    let filteredUsers = defaultUsers

    // Filter first
    if (searchTerm) {
      filteredUsers = filteredUsers.filter((user) =>
        user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (user.phone && user.phone.includes(searchTerm))
      )
    }

    // Country filter
    if (countryFilter) {
      filteredUsers = filteredUsers.filter(user => (user.country || '').toLowerCase() === countryFilter.toLowerCase())
    }

  // Status filter
    if (statusFilter !== 'ALL') {
      const shouldBeSuspended = statusFilter === 'SUSPENDED'
      filteredUsers = filteredUsers.filter(user => 
        shouldBeSuspended ? user.is_suspended : !user.is_suspended
      )
    }
    // Sort
    if (sortConfig !== null) {
      filteredUsers = [...filteredUsers].sort((a, b) => {
        if (sortConfig.key === 'createdAt') {
          const aTime = new Date(a.createdAt).getTime()
          const bTime = new Date(b.createdAt).getTime()
          return sortConfig.direction === 'asc' ? aTime - bTime : bTime - aTime
        }
        const aVal = (a[sortConfig.key] ?? '').toString().toLowerCase()
        const bVal = (b[sortConfig.key] ?? '').toString().toLowerCase()
        if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1
        if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1
        return 0
      })
    }

    return filteredUsers
  }

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10))
    setPage(0)
  }

  const handleDeleteUserClick = (id: string) => {
    setDeleteUserId(id)
    setDeleteDialogOpen(true)
  }

  const handleDeleteUser = async () => {
    try {
      setLoading(true)
      const response = await (await api).userManagement.delete(deleteUserId)

      if (response.status === 200) {
        setNotificationMessage('User deleted successfully')
        setIsOpenNotification(true)
        setDeleteDialogOpen(false)
        getUsers() // Refresh the user list
      } else {
        setNotificationMessage(response.data?.message || 'Error deleting user')
        setIsOpenNotification(true)
      }
    } catch (error: any) {
      console.error('Error deleting user:', error)
      setNotificationMessage(error.response?.data?.message || 'Error deleting user')
      setIsOpenNotification(true)
    } finally {
      setLoading(false)
    }
  }

  const handleToggleSuspend = async (user: User) => {
    try {
      setSuspendingId(user.id)
      const response = await (await api).userManagement.suspend(user.id, !user.is_suspended)
      if (response.status === 200) {
        setNotificationMessage(!user.is_suspended ? 'User suspended' : 'User unsuspended')
        setIsOpenNotification(true)
        getUsers()
      } else {
        setNotificationMessage(response.data?.message || 'Error updating user status')
        setIsOpenNotification(true)
      }
    } catch (error: any) {
      console.error('Error suspending user:', error)
      setNotificationMessage(error.response?.data?.message || 'Error suspending user')
      setIsOpenNotification(true)
    } finally {
      setSuspendingId('')
    }
  }

  const handleViewUserClick = (user: User) => {
    router.push(`/admin/user/${user.id}`)
  }

  const handleEditUserClick = (user: User) => {
    router.push(`/admin/user/${user.id}/edit`)
  }

  const handleSearchUser = (searchTerm: string) => {
    setSearchTerm(searchTerm)
    setPage(0) // reset to first page on search
  }

  // Get filtered and sorted users before pagination
  const filteredSortedUsers = getFilteredSortedUsers()

  return (
    <Box>
      <Box sx={{ width: '100%' }}>
        <Paper sx={{ width: '100%', mb: 2 }}>
          <Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'} pl={4}>
            <Stack direction={'row'} alignItems={'center'} spacing={2}>
              <Typography variant='h4'>Users</Typography>
              <TextField
                variant='outlined'
                size='small'
                placeholder='Search by username, email or phone...'
                value={searchTerm}
                onChange={e => handleSearchUser(e.target.value)}
                sx={{ width: 300 }}
              />
              <TextField
                select
                size='small'
                label='Status'
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value as any)}
                sx={{ minWidth: 160 }}
              >
               <MenuItem value={'ALL'}>All</MenuItem>
                <MenuItem value={'ACTIVE'}>Active</MenuItem>
                <MenuItem value={'SUSPENDED'}>Suspended</MenuItem>
              </TextField>
            </Stack>
          </Stack>

          <TableContainer>
            <Table sx={{ minWidth: 750 }} aria-labelledby='tableTitle' size="medium">
              <TableHead>
                <TableRow>
                  <TableCell>No</TableCell>
                  <TableCell sortDirection={sortConfig?.key === 'fullName' ? sortConfig.direction : false}>
                    <TableSortLabel
                      active={sortConfig?.key === 'fullName'}
                      direction={sortConfig?.key === 'fullName' ? sortConfig.direction : 'asc'}
                      onClick={() => handleSort('fullName')}
                    >
                      User Name
                    </TableSortLabel>
                  </TableCell>
                  <TableCell sortDirection={sortConfig?.key === 'email' ? sortConfig.direction : false}>
                    <TableSortLabel
                      active={sortConfig?.key === 'email'}
                      direction={sortConfig?.key === 'email' ? sortConfig.direction : 'asc'}
                      onClick={() => handleSort('email')}
                    >
                      Email
                    </TableSortLabel>
                  </TableCell>
                  <TableCell sortDirection={sortConfig?.key === 'phone' ? sortConfig.direction : false}>
                    <TableSortLabel
                      active={sortConfig?.key === 'phone'}
                      direction={sortConfig?.key === 'phone' ? sortConfig.direction : 'asc'}
                      onClick={() => handleSort('phone')}
                    >
                      Phone Number
                    </TableSortLabel>
                  </TableCell>
                  <TableCell sortDirection={sortConfig?.key === 'createdAt' ? sortConfig.direction : false}>
                    <TableSortLabel
                      active={sortConfig?.key === 'createdAt'}
                      direction={sortConfig?.key === 'createdAt' ? sortConfig.direction : 'asc'}
                      onClick={() => handleSort('createdAt')}
                    >
                      Registered On
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>Address</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} align='center'>
                      Loading...
                    </TableCell>
                  </TableRow>
                ) : filteredSortedUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align='center'>
                      No users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredSortedUsers
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((user, index) => (
                      <TableRow key={user._id}>
                        <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                        <TableCell>{user.fullName}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.phone || '-'}</TableCell>
                        <TableCell>{new Date(user.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>{user.location || '-'}</TableCell>

                        <TableCell>
                          <Stack direction='row' spacing={2}>
                            <Button variant='outlined' size='small' onClick={() => handleViewUserClick(user)}>
                              View
                            </Button>
                            <Button
                              variant='outlined'
                              color={user.is_suspended ? 'inherit' : 'warning'}
                              size='small'
                              onClick={() => handleToggleSuspend(user)}
                              disabled={loading || suspendingId === user.id}
                            >
                              {suspendingId === user.id ? 'Updating...' : user.is_suspended ? 'Unsuspend' : 'Suspend'}
                            </Button>
                            <Button
                              variant='outlined'
                              color='error'
                              size='small'
                              onClick={() => handleDeleteUserClick(user.id)}
                              disabled={loading}
                            >
                              Delete
                            </Button>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component='div'
            count={filteredSortedUsers.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Paper>
      </Box>

      <Dialog open={deleteDialogOpen} onClose={() => !loading && setDeleteDialogOpen(false)}>
        <DialogTitle>Delete User</DialogTitle>
        <DialogContent>
          <DialogContentText>Are you sure you want to delete this user? This action cannot be undone.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleDeleteUser} color='error' disabled={loading} autoFocus>
            {loading ? 'Deleting...' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      <Notification open={isOpenNotification} onClose={() => setIsOpenNotification(false)} message={notificationMessage} />
    </Box>
  )
}

export default UserPage
