'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import {
    Box,
    Button,
    Card,
    CardContent,
    CardHeader,
    Divider,
    Grid,
    TextField,
    Stack,
    CircularProgress
} from '@mui/material'

import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'

const EditPlanPage = () => {
    const [formData, setFormData] = useState({
        noOfQrCode: '',
        price: ''
    })
    const [errors, setErrors] = useState({
        noOfQrCode: '',
        price: ''
    })
    const [isOpenNotification, setIsOpenNotification] = useState(false)
    const [notificationMessage, setNotificationMessage] = useState('')
    const [loading, setLoading] = useState(false)
    const [fetchLoading, setFetchLoading] = useState(true)

    const router = useRouter()
    const params = useParams()
    const api = useAPI()
    const planId = params.id as string

    useEffect(() => {
        const fetchPlan = async () => {
            try {
                setFetchLoading(true)
                const response = await (await api).plan.getById(planId)
                if (response.data?.data) {
                    const plan = response.data.data
                    setFormData({
                        noOfQrCode: plan.noOfQrCode,
                        price: plan.price
                    })
                }
            } catch (error: any) {
                console.error('Error fetching plan:', error)
                setNotificationMessage(error.response?.data?.message || 'Error fetching plan')
                setIsOpenNotification(true)
            } finally {
                setFetchLoading(false)
            }
        }

        if (planId) {
            fetchPlan()
        }
    }, [planId])

    const validateForm = () => {
        let isValid = true
        const newErrors = {
            noOfQrCode: '',
            price: ''
        }

        if (!formData.noOfQrCode.trim()) {
            newErrors.noOfQrCode = 'Number of QR Codes is required'
            isValid = false
        } else if (isNaN(Number(formData.noOfQrCode)) || Number(formData.noOfQrCode) <= 0) {
            newErrors.noOfQrCode = 'Please enter a valid positive number'
            isValid = false
        }

        if (!formData.price.trim()) {
            newErrors.price = 'Price is required'
            isValid = false
        } else if (isNaN(Number(formData.price)) || Number(formData.price) <= 0) {
            newErrors.price = 'Please enter a valid positive price'
            isValid = false
        }

        setErrors(newErrors)
        return isValid
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({
            ...prev,
            [name]: value
        }))
        // Clear error when user starts typing
        if (errors[name as keyof typeof errors]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }))
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!validateForm()) {
            return
        }

        try {
            setLoading(true)
            const response = await (await api).plan.update(planId, formData)

            if (response.status === 200) {
                setNotificationMessage('Plan updated successfully')
                setIsOpenNotification(true)
                setTimeout(() => {
                    router.push('/admin/plan')
                }, 1500)
            } else {
                setNotificationMessage(response.data?.message || 'Error updating plan')
                setIsOpenNotification(true)
            }
        } catch (error: any) {
            console.error('Error updating plan:', error)
            setNotificationMessage(error.response?.data?.message || 'Error updating plan')
            setIsOpenNotification(true)
        } finally {
            setLoading(false)
        }
    }

    const handleCancel = () => {
        router.push('/admin/plan')
    }

    if (fetchLoading) {
        return (
            <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
                <CircularProgress />
            </Box>
        )
    }

    return (
        <Box>
            <form onSubmit={handleSubmit}>
                <Card>
                    <CardHeader
                        title="Edit Plan"
                        subheader="Update plan details including QR code allocation and pricing"
                    />
                    <Divider />
                    <CardContent>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={6}>
                                <TextField
                                    fullWidth
                                    label="Number of QR Codes"
                                    name="noOfQrCode"
                                    type="number"
                                    value={formData.noOfQrCode}
                                    onChange={handleChange}
                                    error={!!errors.noOfQrCode}
                                    helperText={errors.noOfQrCode}
                                    required
                                    inputProps={{ min: 1 }}
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <TextField
                                    fullWidth
                                    label="Price"
                                    name="price"
                                    type="number"
                                    value={formData.price}
                                    onChange={handleChange}
                                    error={!!errors.price}
                                    helperText={errors.price}
                                    required
                                    inputProps={{ min: 0, step: '0.01' }}
                                    InputProps={{
                                        startAdornment: '$'
                                    }}
                                />
                            </Grid>
                        </Grid>
                    </CardContent>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
                        <Stack direction="row" spacing={2}>
                            <Button
                                color="inherit"
                                onClick={handleCancel}
                                disabled={loading}
                            >
                                Cancel
                            </Button>
                            <Button
                                color="primary"
                                variant="contained"
                                type="submit"
                                disabled={loading}
                            >
                                {loading ? 'Updating...' : 'Update Plan'}
                            </Button>
                        </Stack>
                    </Box>
                </Card>
            </form>

            <Notification
                open={isOpenNotification}
                onClose={() => setIsOpenNotification(false)}
                message={notificationMessage}
            />
        </Box>
    )
}

export default EditPlanPage
