'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

import {
    Box,
    Button,
    Paper,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TablePagination,
    TableRow,
    Typography,
    TextField,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle,
    TableSortLabel
} from '@mui/material'

import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'

interface Plan {
    _id: string
    id: string
    noOfQrCode: string
    price: string
    createdAt: string
    updatedAt: string
}

type SortKey = 'noOfQrCode' | 'price' | 'createdAt'

const PlanPage = () => {
    const [page, setPage] = useState(0)
    const [rowsPerPage, setRowsPerPage] = useState(10)
    const [plans, setPlans] = useState<Plan[]>([])
    const [defaultPlans, setDefaultPlans] = useState<Plan[]>([])
    const [searchTerm, setSearchTerm] = useState('')
    const [deletePlanId, setDeletePlanId] = useState('')
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
    const [isOpenNotification, setIsOpenNotification] = useState(false)
    const [notificationMessage, setNotificationMessage] = useState('')
    const [loading, setLoading] = useState(false)
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' } | null>(null)

    const router = useRouter()
    const api = useAPI()

    const getPlans = async () => {
        try {
            setLoading(true)
            const response = await (await api).plan.get()
            if (response.data?.data) {
                setPlans(response.data.data)
                setDefaultPlans(response.data.data)
            }
        } catch (error: any) {
            console.error('Error fetching plans:', error)
            setNotificationMessage(error.response?.data?.message || 'Error fetching plans')
            setIsOpenNotification(true)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        getPlans()
    }, [])

    const handleSort = (key: SortKey) => {
        let direction: 'asc' | 'desc' = 'asc'
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc'
        }
        setSortConfig({ key, direction })
    }

    const getFilteredSortedPlans = () => {
        let filteredPlans = defaultPlans

        if (searchTerm) {
            filteredPlans = filteredPlans.filter((plan) =>
                plan.noOfQrCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                plan.price.toLowerCase().includes(searchTerm.toLowerCase())
            )
        }

        if (sortConfig !== null) {
            filteredPlans = [...filteredPlans].sort((a, b) => {
                if (sortConfig.key === 'createdAt') {
                    const aTime = new Date(a.createdAt).getTime()
                    const bTime = new Date(b.createdAt).getTime()
                    return sortConfig.direction === 'asc' ? aTime - bTime : bTime - aTime
                }

                if (sortConfig.key === 'noOfQrCode' || sortConfig.key === 'price') {
                    const aVal = parseFloat(a[sortConfig.key]) || 0
                    const bVal = parseFloat(b[sortConfig.key]) || 0
                    return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal
                }

                return 0
            })
        }

        return filteredPlans
    }

    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage)
    }

    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(parseInt(event.target.value, 10))
        setPage(0)
    }

    const handleDeletePlanClick = (id: string) => {
        setDeletePlanId(id)
        setDeleteDialogOpen(true)
    }

    const handleDeletePlan = async () => {
        try {
            setLoading(true)
            const response = await (await api).plan.delete(deletePlanId)

            if (response.status === 200) {
                setNotificationMessage('Plan deleted successfully')
                setIsOpenNotification(true)
                setDeleteDialogOpen(false)
                getPlans()
            } else {
                setNotificationMessage(response.data?.message || 'Error deleting plan')
                setIsOpenNotification(true)
            }
        } catch (error: any) {
            console.error('Error deleting plan:', error)
            setNotificationMessage(error.response?.data?.message || 'Error deleting plan')
            setIsOpenNotification(true)
        } finally {
            setLoading(false)
        }
    }

    const handleAddPlanClick = () => {
        router.push('/admin/plan/add')
    }

    const handleEditPlanClick = (plan: Plan) => {
        router.push(`/admin/plan/${plan.id}/edit`)
    }

    const handleSearchPlan = (searchTerm: string) => {
        setSearchTerm(searchTerm)
        setPage(0)
    }

    const filteredSortedPlans = getFilteredSortedPlans()

    return (
        <Box>
            <Box sx={{ width: '100%' }}>
                <Paper sx={{ width: '100%', mb: 2 }}>
                    <Stack direction={'row'} justifyContent={'space-between'} alignItems={'center'} p={2} pl={4}>
                        <Stack direction={'row'} alignItems={'center'} spacing={2}>
                            <Typography variant='h4'>Plans</Typography>
                            <TextField
                                variant='outlined'
                                size='small'
                                placeholder='Search by QR code count or price...'
                                value={searchTerm}
                                onChange={e => handleSearchPlan(e.target.value)}
                                sx={{ width: 300 }}
                            />
                        </Stack>
                    </Stack>

                    <TableContainer>
                        <Table sx={{ minWidth: 750 }} aria-labelledby='tableTitle' size="medium">
                            <TableHead>
                                <TableRow>
                                    <TableCell>No</TableCell>
                                    <TableCell sortDirection={sortConfig?.key === 'noOfQrCode' ? sortConfig.direction : false}>
                                        <TableSortLabel
                                            active={sortConfig?.key === 'noOfQrCode'}
                                            direction={sortConfig?.key === 'noOfQrCode' ? sortConfig.direction : 'asc'}
                                            onClick={() => handleSort('noOfQrCode')}
                                        >
                                            Number of QR Codes
                                        </TableSortLabel>
                                    </TableCell>
                                    <TableCell sortDirection={sortConfig?.key === 'price' ? sortConfig.direction : false}>
                                        <TableSortLabel
                                            active={sortConfig?.key === 'price'}
                                            direction={sortConfig?.key === 'price' ? sortConfig.direction : 'asc'}
                                            onClick={() => handleSort('price')}
                                        >
                                            Price
                                        </TableSortLabel>
                                    </TableCell>
                                    <TableCell sortDirection={sortConfig?.key === 'createdAt' ? sortConfig.direction : false}>
                                        <TableSortLabel
                                            active={sortConfig?.key === 'createdAt'}
                                            direction={sortConfig?.key === 'createdAt' ? sortConfig.direction : 'asc'}
                                            onClick={() => handleSort('createdAt')}
                                        >
                                            Created At
                                        </TableSortLabel>
                                    </TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {loading ? (
                                    <TableRow>
                                        <TableCell colSpan={5} align='center'>
                                            Loading...
                                        </TableCell>
                                    </TableRow>
                                ) : filteredSortedPlans.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={5} align='center'>
                                            No plans found
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    filteredSortedPlans
                                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        .map((plan, index) => (
                                            <TableRow key={plan._id}>
                                                <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                                                <TableCell>{plan.noOfQrCode}</TableCell>
                                                <TableCell>{plan.price}</TableCell>
                                                <TableCell>{new Date(plan.createdAt).toLocaleDateString()}</TableCell>
                                            </TableRow>
                                        ))
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                    <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component='div'
                        count={filteredSortedPlans.length}
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                </Paper>
            </Box>

            <Dialog open={deleteDialogOpen} onClose={() => !loading && setDeleteDialogOpen(false)}>
                <DialogTitle>Delete Plan</DialogTitle>
                <DialogContent>
                    <DialogContentText>Are you sure you want to delete this plan? This action cannot be undone.</DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDeleteDialogOpen(false)} disabled={loading}>
                        Cancel
                    </Button>
                    <Button onClick={handleDeletePlan} color='error' disabled={loading} autoFocus>
                        {loading ? 'Deleting...' : 'Delete'}
                    </Button>
                </DialogActions>
            </Dialog>

            <Notification open={isOpenNotification} onClose={() => setIsOpenNotification(false)} message={notificationMessage} />
        </Box>
    )
}

export default PlanPage
