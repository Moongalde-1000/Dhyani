'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
    Box,
    Button,
    Card,
    CardContent,
    CardHeader,
    Divider,
    Grid,
    TextField,
    Stack
} from '@mui/material'

import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'

const AddPlanPage = () => {
    const [formData, setFormData] = useState({
        noOfQrCode: '',
        price: ''
    })
    const [errors, setErrors] = useState({
        noOfQrCode: '',
        price: ''
    })
    const [isOpenNotification, setIsOpenNotification] = useState(false)
    const [notificationMessage, setNotificationMessage] = useState('')
    const [loading, setLoading] = useState(false)

    const router = useRouter()
    const api = useAPI()

    const validateForm = () => {
        let isValid = true
        const newErrors = {
            noOfQrCode: '',
            price: ''
        }

        if (!formData.noOfQrCode.trim()) {
            newErrors.noOfQrCode = 'Number of QR Codes is required'
            isValid = false
        } else if (isNaN(Number(formData.noOfQrCode)) || Number(formData.noOfQrCode) <= 0) {
            newErrors.noOfQrCode = 'Please enter a valid positive number'
            isValid = false
        }

        if (!formData.price.trim()) {
            newErrors.price = 'Price is required'
            isValid = false
        } else if (isNaN(Number(formData.price)) || Number(formData.price) <= 0) {
            newErrors.price = 'Please enter a valid positive price'
            isValid = false
        }

        setErrors(newErrors)
        return isValid
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({
            ...prev,
            [name]: value
        }))
        // Clear error when user starts typing
        if (errors[name as keyof typeof errors]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }))
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!validateForm()) {
            return
        }

        try {
            setLoading(true)
            const response = await (await api).plan.create(formData)

            if (response.status === 201) {
                setNotificationMessage('Plan created successfully')
                setIsOpenNotification(true)
                setTimeout(() => {
                    router.push('/admin/plan')
                }, 1500)
            } else {
                setNotificationMessage(response.data?.message || 'Error creating plan')
                setIsOpenNotification(true)
            }
        } catch (error: any) {
            console.error('Error creating plan:', error)
            setNotificationMessage(error.response?.data?.message || 'Error creating plan')
            setIsOpenNotification(true)
        } finally {
            setLoading(false)
        }
    }

    const handleCancel = () => {
        router.push('/admin/plan')
    }

    return (
        <Box>
            <form onSubmit={handleSubmit}>
                <Card>
                    <CardHeader
                        title="Add New Plan"
                        subheader="Create a new plan with QR code allocation and pricing"
                    />
                    <Divider />
                    <CardContent>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={6}>
                                <TextField
                                    fullWidth
                                    label="Number of QR Codes"
                                    name="noOfQrCode"
                                    type="number"
                                    value={formData.noOfQrCode}
                                    onChange={handleChange}
                                    error={!!errors.noOfQrCode}
                                    helperText={errors.noOfQrCode}
                                    required
                                    inputProps={{ min: 1 }}
                                />
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <TextField
                                    fullWidth
                                    label="Price"
                                    name="price"
                                    type="number"
                                    value={formData.price}
                                    onChange={handleChange}
                                    error={!!errors.price}
                                    helperText={errors.price}
                                    required
                                    inputProps={{ min: 0, step: '0.01' }}
                                    InputProps={{
                                        startAdornment: '$'
                                    }}
                                />
                            </Grid>
                        </Grid>
                    </CardContent>
                    <Divider />
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
                        <Stack direction="row" spacing={2}>
                            <Button
                                color="inherit"
                                onClick={handleCancel}
                                disabled={loading}
                            >
                                Cancel
                            </Button>
                            <Button
                                color="primary"
                                variant="contained"
                                type="submit"
                                disabled={loading}
                            >
                                {loading ? 'Creating...' : 'Create Plan'}
                            </Button>
                        </Stack>
                    </Box>
                </Card>
            </form>

            <Notification
                open={isOpenNotification}
                onClose={() => setIsOpenNotification(false)}
                message={notificationMessage}
            />
        </Box>
    )
}

export default AddPlanPage
