'use client'

import { useEffect, useMemo, useState } from 'react'
import type { ChangeEvent, FormEvent } from 'react'
import { useParams, useRouter } from 'next/navigation'

import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  Grid,
  Stack,
  TextField,
  Typography
} from '@mui/material'

import useAPI from '@/hooks/useAPI'
import Notification from '@/app/admin/notification'
import type { StaticPageItem } from '@/services/staticPageAPI'

const FULL_DETAILS_PAGE_ID = '6901fc2228daea01d108908f'

const EMPTY_FORM = {
  pageTitle: '',
  description: '',
  phone: '',
  email: '',
  location: ''
}

const StaticPageEdit = () => {
  const router = useRouter()
  const params = useParams<{ id: string }>()
  const pageId = useMemo(() => {
    if (!params?.id) return ''
    return Array.isArray(params.id) ? params.id[0] : params.id
  }, [params])

  const api = useAPI()
  const showContactFields = pageId === FULL_DETAILS_PAGE_ID

  const [formValues, setFormValues] = useState(EMPTY_FORM)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [isOpenNotification, setIsOpenNotification] = useState(false)
  const [notificationMessage, setNotificationMessage] = useState('')

  const fetchStaticPage = async (id: string) => {
    try {
      setLoading(true)
      const response = await (await api).staticPage.getById(id)
      const data: StaticPageItem | undefined = response.data?.data
      if (data) {
        setFormValues({
          pageTitle: data.pageTitle || '',
          description: data.description || '',
          phone: data.phone || '',
          email: data.email || '',
          location: data.location || ''
        })
        setPreviewImage(data.staticImage || null)
      }
    } catch (error: any) {
      console.error('Failed to load static page:', error)
      setNotificationMessage(error.response?.data?.message || 'Failed to load static page')
      setIsOpenNotification(true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (pageId) {
      fetchStaticPage(pageId)
    } else {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageId])

  const handleInputChange = (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = event.target
    setFormValues(prev => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    setSelectedFile(file || null)
    if (file) {
      setPreviewImage(URL.createObjectURL(file))
    } else {
      setPreviewImage(prev => prev)
    }
  }

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!pageId) return
    try {
      setSubmitting(true)
      const formData = new FormData()
      formData.append('pageTitle', formValues.pageTitle)
      formData.append('description', formValues.description)
      if (showContactFields) {
        formData.append('phone', formValues.phone)
        formData.append('email', formValues.email)
        formData.append('location', formValues.location)
      }
      if (selectedFile) {
        formData.append('staticImage', selectedFile)
      }

      await (await api).staticPage.update(pageId, formData)
      setNotificationMessage('Static page updated successfully')
      setIsOpenNotification(true)
      router.push('/admin/static-pages')
    } catch (error: any) {
      console.error('Failed to update static page:', error)
      setNotificationMessage(error.response?.data?.message || 'Failed to update static page')
      setIsOpenNotification(true)
    } finally {
      setSubmitting(false)
    }
  }

  if (!pageId) {
    return (
      <Box>
        <Typography variant='h5' mb={2}>
          Invalid static page
        </Typography>
        <Button variant='contained' onClick={() => router.push('/admin/static-pages')}>
          Go back
        </Button>
      </Box>
    )
  }

  return (
    <Box component='form' onSubmit={handleSubmit}>
      <Stack direction='row' alignItems='center' justifyContent='space-between' mb={4} flexWrap='wrap' gap={2}>
        <Box>
          <Typography variant='h4'>Edit Static Page</Typography>
          <Typography color='text.secondary'>Update the content and image for this static page.</Typography>
        </Box>
        <Stack direction='row' spacing={2}>
          <Button variant='outlined' onClick={() => router.push('/admin/static-pages')} disabled={submitting}>
            Cancel
          </Button>
          <Button variant='contained' type='submit' disabled={submitting || loading}>
            {submitting ? 'Saving...' : 'Save Changes'}
          </Button>
        </Stack>
      </Stack>

      {loading ? (
        <Stack alignItems='center' justifyContent='center' height={240}>
          <CircularProgress />
        </Stack>
      ) : (
        <Card>
          <CardContent>
            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                <TextField
                  fullWidth
                  label='Page Title'
                  name='pageTitle'
                  value={formValues.pageTitle}
                  onChange={handleInputChange}
                  required
                  sx={{ mb: 4 }}
                />
                <TextField
                  fullWidth
                  label='Description'
                  name='description'
                  value={formValues.description}
                  onChange={handleInputChange}
                  required
                  multiline
                  minRows={4}
                  sx={{ mb: 4 }}
                />
                {showContactFields && (
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                      <TextField
                        fullWidth
                        label='Phone'
                        name='phone'
                        value={formValues.phone}
                        onChange={handleInputChange}
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        fullWidth
                        label='Email'
                        name='email'
                        value={formValues.email}
                        onChange={handleInputChange}
                        type='email'
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        fullWidth
                        label='Location'
                        name='location'
                        value={formValues.location}
                        onChange={handleInputChange}
                      />
                    </Grid>
                  </Grid>
                )}
              </Grid>
              <Grid item xs={12} md={4}>
                <Typography variant='subtitle1' gutterBottom>
                  Static Image
                </Typography>
                <Stack spacing={2} alignItems='flex-start'>
                  <Avatar
                    variant='rounded'
                    src={previewImage || undefined}
                    sx={{ width: 200, height: 120 }}
                  >
                    {!previewImage && 'No Image'}
                  </Avatar>
                  <Button variant='outlined' component='label'>
                    Upload New Image
                    <input type='file' hidden accept='image/*' onChange={handleFileChange} />
                  </Button>
                  {selectedFile && (
                    <Typography variant='body2' color='text.secondary'>
                      Selected: {selectedFile.name}
                    </Typography>
                  )}
                </Stack>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      )}

      <Notification open={isOpenNotification} onClose={() => setIsOpenNotification(false)} message={notificationMessage} />
    </Box>
  )
}

export default StaticPageEdit

