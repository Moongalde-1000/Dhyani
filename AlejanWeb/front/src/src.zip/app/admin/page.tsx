"use client";

import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Grid, Stack, Typography } from '@mui/material';

import useAPI from '@/hooks/useAPI';
import Notification from '@/app/admin/notification';

const DashboardAnalytics = () => {
  const router = useRouter(); // Correct hook for App Router
  const api = useAPI()
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalPlans, setTotalPlans] = useState(0);
  const [loading, setLoading] = useState(false);
  const [isOpenNotification, setIsOpenNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState('');

  const getData = async () => {
    try {
      setLoading(true);
      const [usersRes, plansRes] = await Promise.all([
        (await api).userManagement.get(),
        (await api).plan.get()
      ]);

      if (usersRes.data?.data) setTotalUsers(usersRes.data.data.length);
      if (plansRes.data?.data) setTotalPlans(plansRes.data.data.length);
    } catch (error: any) {
      console.error('Error fetching data:', error);
      setNotificationMessage(error.response?.data?.message || 'Error fetching dashboard data');
      setIsOpenNotification(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getData()
  }, [])

  const handleRedirect = (path: string) => {
    router.push(path); // Navigate to the manage page
  }

  return (
    <Grid container spacing={6} justifyContent="center" sx={{ mt: 2 }}>
      <Grid item xs={12} md={6} lg={4}>
        <div onClick={() => handleRedirect('/admin/plan')} style={{ cursor: 'pointer' }}>
          <Card sx={{ width: '100%' }}>
            <CardContent>
              <Stack direction={'row'} justifyContent={'space-between'}>
                <Typography variant="h6">Total Plans</Typography>
                <i className="ri-file-list-3-line text-[26px]"></i>
              </Stack>
              <Typography variant="h4" sx={{ mt: 2, mb: 1 }}>
                {loading ? 'Loading...' : totalPlans.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Click to manage plans
              </Typography>
            </CardContent>
          </Card>
        </div>
      </Grid>
      <Grid item xs={12} md={6} lg={4}>
        <div onClick={() => handleRedirect('/admin/user')} style={{ cursor: 'pointer' }}>
          <Card sx={{ width: '100%' }}>
            <CardContent>
              <Stack direction={'row'} justifyContent={'space-between'}>
                <Typography variant="h6">Total Users</Typography>
                <i className="ri-user-line text-[26px]"></i>
              </Stack>
              <Typography variant="h4" sx={{ mt: 2, mb: 1 }}>
                {loading ? 'Loading...' : totalUsers.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Click to manage users
              </Typography>
            </CardContent>
          </Card>
        </div>
      </Grid>
      <Notification
        open={isOpenNotification}
        onClose={() => setIsOpenNotification(false)}
        message={notificationMessage}
      />
    </Grid>
  )
}

export default DashboardAnalytics
