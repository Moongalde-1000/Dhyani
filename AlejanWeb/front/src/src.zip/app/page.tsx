'use client'

import React, { useEffect, useState } from 'react'
import Script from 'next/script'
import useAPI from '../hooks/useAPI'

// Style Imports
import './style.css'
import './responsive.css'

const LandingPage = () => {
    console.log('LandingPage Rendering...');

    const api = useAPI();
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        subject: '',
        message: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitMessage, setSubmitMessage] = useState('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        setSubmitMessage('');

        try {
            const apiInstance = await api;
            await apiInstance.contact.create(formData);
            setSubmitMessage('Thank you for your message! We will get back to you soon.');
            setFormData({
                name: '',
                phone: '',
                email: '',
                subject: '',
                message: ''
            });
        } catch (error) {
            setSubmitMessage('Failed to submit form. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    // Auto-hide message after 5 seconds
    useEffect(() => {
        if (submitMessage) {
            const timer = setTimeout(() => {
                setSubmitMessage('');
            }, 5000);

            return () => clearTimeout(timer);
        }
    }, [submitMessage]);

    return (
        <>


            {/* Hero Section with Header */}
            <section className="hero-section">
                {/* Header Navigation */}
                <header className="main-header">
                    <div className="container">
                        <div className="header-wrapper">
                            <div className="logo">
                                <img src="/images/logo (1).png" alt="Logo" />
                            </div>

                            {/* Mobile Menu Toggle */}
                            <button className="mobile-menu-toggle" id="mobileMenuToggle">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>

                            <nav className="main-nav" id="mainNav">
                                <ul>
                                    <li><a href="#" className="active">Home</a></li>
                                    <li><a href="#about">About Us</a></li>
                                    <li><a href="#contact">Contact Us</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </header>

                {/* Banner Slider */}
                <div className="banner-slider">
                    <div className="banner-slide">
                        <div className="container">
                            <div className="row align-items-center">
                                <div className="col-lg-5">
                                    <div className="hero-content">
                                        <h1>Lorem Ipsum is sim<br />ply dummy text</h1>

                                        <div className="download-buttons">
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-apple"></i>
                                                <div className="download-btn-text">
                                                    <small>Download on the</small>
                                                    <span>App Store</span>
                                                </div>
                                            </a>
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-google-play"></i>
                                                <div className="download-btn-text">
                                                    <small>GET IT ON</small>
                                                    <span>Google Play</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-7">
                                    <div className="hero-phones">
                                        <div className="phone-mockup">
                                            <img src="/images/jayy.png" alt="Profile Screen" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="banner-slide">
                        <div className="container">
                            <div className="row align-items-center">
                                <div className="col-lg-5">
                                    <div className="hero-content">
                                        <h1>Find Your Perfect<br />Match Today</h1>

                                        <div className="download-buttons">
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-apple"></i>
                                                <div className="download-btn-text">
                                                    <small>Download on the</small>
                                                    <span>App Store</span>
                                                </div>
                                            </a>
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-google-play"></i>
                                                <div className="download-btn-text">
                                                    <small>GET IT ON</small>
                                                    <span>Google Play</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-7">
                                    <div className="hero-phones">
                                        <div className="phone-mockup">
                                            <img src="/images/jayy.png" alt="Chat Screen" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="banner-slide">
                        <div className="container">
                            <div className="row align-items-center">
                                <div className="col-lg-5">
                                    <div className="hero-content">
                                        <h1>Connect With<br />Like-Minded People</h1>

                                        <div className="download-buttons">
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-apple"></i>
                                                <div className="download-btn-text">
                                                    <small>Download on the</small>
                                                    <span>App Store</span>
                                                </div>
                                            </a>
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-google-play"></i>
                                                <div className="download-btn-text">
                                                    <small>GET IT ON</small>
                                                    <span>Google Play</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-7">
                                    <div className="hero-phones">
                                        <div className="phone-mockup">
                                            <img src="/images/jayy.png" alt="Profile Screen" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="banner-slide">
                        <div className="container">
                            <div className="row align-items-center">
                                <div className="col-lg-5">
                                    <div className="hero-content">
                                        <h1>Start Your Love<br />Story Now</h1>

                                        <div className="download-buttons">
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-apple"></i>
                                                <div className="download-btn-text">
                                                    <small>Download on the</small>
                                                    <span>App Store</span>
                                                </div>
                                            </a>
                                            <a href="#" className="download-btn">
                                                <i className="fab fa-google-play"></i>
                                                <div className="download-btn-text">
                                                    <small>GET IT ON</small>
                                                    <span>Google Play</span>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-lg-7">
                                    <div className="hero-phones">
                                        <div className="phone-mockup">
                                            <img src="/images/jayy.png" alt="Profile Screen" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Welcome Section */}
            <section className="welcome-section" id="about">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-6">
                            <div className="welcome-content">
                                <h2>Welcome to<br />Book My Love</h2>
                                <p>Lorem Ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                                    labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                    laboris nisi ut aliquip ex ea commodo.</p>
                                <p>consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui
                                    officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error
                                    sit voluptatem accusantium.</p>
                                <a href="#" className="read-more-btn">Read More</a>
                            </div>
                        </div>

                        <div className="col-lg-6">
                            <div className="phone-showcase">
                                <img src="/images/image.png" alt="Book My Love App" />
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Testimonials Section */}
            <section className="testimonials-section">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3">
                            <div className="testimonials-header">
                                <h2>Our<br />Testimonials</h2>
                                <div className="testimonial-nav-arrows">
                                    <button className="testimonial-prev"><i className="fas fa-chevron-left"></i></button>
                                    <button className="testimonial-next"><i className="fas fa-chevron-right"></i></button>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-9">
                            <div className="testimonials-slider">
                                <div className="testimonial-slide">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="testimonial-card">
                                                <div className="testimonial-avatar">
                                                    <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop"
                                                        alt="Romarola D. Pong" />
                                                </div>
                                                <div className="testimonial-name">Romarola D. Pong</div>
                                                <p className="testimonial-text">Lorem Ipsum is simply dummy text of the printing and
                                                    typesetting industry. Lorem Ipsum has been the industry&apos;s standard dummy
                                                    text ever since the 1500s, when an unknown printer took a galley of scerif
                                                    to with desktop publishing software like Aldus PageMaker including versions
                                                    of Lorem Ipsum.</p>
                                            </div>
                                        </div>

                                        <div className="col-md-6">
                                            <div className="testimonial-card">
                                                <div className="testimonial-avatar">
                                                    <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop"
                                                        alt="Romarola D. Pong" />
                                                </div>
                                                <div className="testimonial-name">Romarola D. Pong</div>
                                                <p className="testimonial-text">Lorem Ipsum is simply dummy text of the printing and
                                                    typesetting industry. Lorem Ipsum has been the industry&apos;s standard dummy
                                                    text ever since the 1500s, when an unknown printer took a galley of scerif
                                                    to with desktop publishing software like Aldus PageMaker including versions
                                                    of Lorem Ipsum.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="testimonial-slide">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="testimonial-card">
                                                <div className="testimonial-avatar">
                                                    <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop"
                                                        alt="Sarah Williams" />
                                                </div>
                                                <div className="testimonial-name">Sarah Williams</div>
                                                <p className="testimonial-text">Lorem Ipsum is simply dummy text of the printing and
                                                    typesetting industry. Lorem Ipsum has been the industry&apos;s standard dummy
                                                    text ever since the 1500s, when an unknown printer took a galley of scerif
                                                    to with desktop publishing software like Aldus PageMaker including versions
                                                    of Lorem Ipsum.</p>
                                            </div>
                                        </div>

                                        <div className="col-md-6">
                                            <div className="testimonial-card">
                                                <div className="testimonial-avatar">
                                                    <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop"
                                                        alt="David Martinez" />
                                                </div>
                                                <div className="testimonial-name">David Martinez</div>
                                                <p className="testimonial-text">Lorem Ipsum is simply dummy text of the printing and
                                                    typesetting industry. Lorem Ipsum has been the industry&apos;s standard dummy
                                                    text ever since the 1500s, when an unknown printer took a galley of scerif
                                                    to with desktop publishing software like Aldus PageMaker including versions
                                                    of Lorem Ipsum.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Contact Section */}
            <section className="contact-section">
                <div className="container">
                    <div className="contact-header">
                        <div className="contact-label">CONTACT</div>
                        <h2>Get In Touch</h2>
                    </div>

                    <div className="row justify-content-center">
                        <form className="contact-form" onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="nameInput">ENTER YOUR NAME</label>
                                        <input
                                            type="text"
                                            id="nameInput"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleInputChange}
                                            placeholder="Type your name here...."
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="phoneInput">ENTER YOUR PHONE</label>
                                        <input
                                            type="tel"
                                            id="phoneInput"
                                            name="phone"
                                            value={formData.phone}
                                            onChange={handleInputChange}
                                            placeholder="Type your phone number...."
                                            required
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="emailInput">ENTER YOUR EMAIL</label>
                                        <input
                                            type="email"
                                            id="emailInput"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleInputChange}
                                            placeholder="Type your email address here...."
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div className="form-group">
                                        <label htmlFor="subjectSelect">ENTER YOUR SUBJECT</label>
                                        <select
                                            id="subjectSelect"
                                            name="subject"
                                            value={formData.subject}
                                            onChange={handleInputChange}
                                            required
                                        >
                                            <option value="">Select A Subject</option>
                                            <option value="general">General Inquiry</option>
                                            <option value="support">Technical Support</option>
                                            <option value="feedback">Feedback</option>
                                            <option value="partnership">Partnership</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="form-group">
                                <label htmlFor="messageTextarea">ENTER YOUR MESSAGE</label>
                                <textarea
                                    id="messageTextarea"
                                    name="message"
                                    value={formData.message}
                                    onChange={handleInputChange}
                                    rows={6}
                                    placeholder="Type your valuable message...."
                                    required
                                ></textarea>
                            </div>

                            {submitMessage && (
                                <div className={`alert ${submitMessage.includes('Thank you') ? 'alert-success' : 'alert-danger'}`} style={{ marginTop: '1rem', padding: '0.75rem', borderRadius: '4px', fontSize: '0.9rem' }}>
                                    {submitMessage}
                                </div>
                            )}

                            <button type="submit" className="submit-btn" disabled={isSubmitting}>
                                {isSubmitting ? 'Submitting...' : 'GET AN ACTION'}
                            </button>
                        </form>
                    </div>

                    <div className="floating-circle" id="scrollToTop">
                        <i className="fas fa-chevron-up"></i>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="footer">
                <div className="container">
                    <div className="footer-logo">
                        <div className="logo" style={{ justifyContent: 'center', marginBottom: '20px' }}>
                            <img src="/images/logo (1).png" alt="Logo" />
                        </div>
                    </div>

                    <p className="footer-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                        Ipsum has been the industry&apos;s standard dummy text ever since the 1500s, when an unknown printer took a
                        galley of type and scrambled it to make a type specimen book.</p>

                    <div className="footer-links">
                        <a href="#">Home</a>
                        <a href="#">About</a>
                        <a href="#">Services</a>
                        <a href="#">Contact</a>
                        <a href="#">Privacy Policy</a>
                    </div>

                    <div className="social-icons">
                        <a href="#" className="social-icon">
                            <i className="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" className="social-icon">
                            <i className="fab fa-twitter"></i>
                        </a>
                        <a href="#" className="social-icon">
                            <i className="fab fa-instagram"></i>
                        </a>
                        <a href="#" className="social-icon">
                            <i className="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" className="social-icon">
                            <i className="fab fa-youtube"></i>
                        </a>
                    </div>

                    <div className="copyright">
                        © 2026 Book My Love - All Rights Reserved
                    </div>
                </div>
            </footer >

            <Script src="https://code.jquery.com/jquery-3.6.0.min.js" strategy="beforeInteractive" />
            <Script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js" strategy="afterInteractive" />
            <Script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" strategy="afterInteractive" />

            <Script id="slick-init" strategy="afterInteractive">
                {`
          $(document).ready(function () {
              // Initialize Slick Slider for Banner
              $('.banner-slider').slick({
                  dots: true,
                  infinite: true,
                  speed: 800,
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  autoplay: true,
                  autoplaySpeed: 5000,
                  arrows: false,
                  pauseOnHover: true,
                  fade: true,
                  cssEase: 'ease-in-out'
              });

              // Initialize Slick Slider for Testimonials
              $('.testimonials-slider').slick({
                  dots: false,
                  infinite: true,
                  speed: 500,
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  autoplay: true,
                  autoplaySpeed: 4000,
                  arrows: false,
                  pauseOnHover: true,
                  responsive: [
                      {
                          breakpoint: 768,
                          settings: {
                              dots: true
                          }
                      }
                  ]
              });

              // Custom navigation arrows
              $('.testimonial-prev').click(function () {
                  $('.testimonials-slider').slick('slickPrev');
              });

              $('.testimonial-next').click(function () {
                  $('.testimonials-slider').slick('slickNext');
              });

              // Scroll to top
              $('#scrollToTop').click(function () {
                  window.scrollTo({
                      top: 0,
                      behavior: 'smooth'
                  });
              });

              // Mobile menu toggle
              const mobileMenuToggle = document.getElementById('mobileMenuToggle');
              const mainNav = document.getElementById('mainNav');

              if (mobileMenuToggle) {
                  mobileMenuToggle.addEventListener('click', function () {
                      this.classList.toggle('active');
                      if (mainNav) mainNav.classList.toggle('active');
                  });
              }

              // Close mobile menu when clicking on a link
              document.querySelectorAll('.main-nav a').forEach(link => {
                  link.addEventListener('click', function () {
                      if (mobileMenuToggle) mobileMenuToggle.classList.remove('active');
                      if (mainNav) mainNav.classList.remove('active');
                  });
              });

              // Close mobile menu when clicking outside
              document.addEventListener('click', function (event) {
                  if (mainNav && mobileMenuToggle && !mainNav.contains(event.target) && !mobileMenuToggle.contains(event.target)) {
                      mobileMenuToggle.classList.remove('active');
                      mainNav.classList.remove('active');
                  }
              });

              // Smooth scrolling for anchor links
              document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                  anchor.addEventListener('click', function (e) {
                      e.preventDefault();
                      const target = document.querySelector(this.getAttribute('href'));
                      if (target) {
                          target.scrollIntoView({
                              behavior: 'smooth'
                          });
                      }
                  });
              });
          });
        `}
            </Script>
        </>
    )
}

export default LandingPage
